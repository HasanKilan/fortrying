from datetime import timedelta
from passlib.context import CryptContext
from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer, HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from app.core.config import settings
from app.db.database import SessionLocal
from app.models.models import User
from app.utils.token import decode_access_token  # ✅ use access token decoder

# Password hashing config
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Auth schemes
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/token")  # for standard routes
http_bearer = HTTPBearer()  # for custom routes

# ✅ Get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ✅ Password utilities
def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

# ✅ Shared token decoding logic (uses utils)
def _decode_token_and_get_user(token: str, db: Session):
    credentials_exception = HTTPException(status_code=401, detail="Invalid credentials")

    payload = decode_access_token(token)
    if payload is None:
        raise credentials_exception

    email = payload.get("sub")
    if email is None:
        raise credentials_exception

    user = db.query(User).filter(User.email == email).first()
    if user is None:
        raise credentials_exception

    return user

# ✅ Standard OAuth2 token user
def get_current_user_oauth2(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
):
    return _decode_token_and_get_user(token, db)

# ✅ HTTP Bearer token user
def get_current_user_http(
    credentials: HTTPAuthorizationCredentials = Depends(http_bearer),
    db: Session = Depends(get_db)
):
    token = credentials.credentials
    return _decode_token_and_get_user(token, db)

# ✅ Role-based access (OAuth2 or HTTPBearer)
def check_role(allowed_roles: list[str], use_http: bool = False):
    def role_checker(
        user: User = Depends(get_current_user_http if use_http else get_current_user_oauth2)
    ):
        if user.role not in allowed_roles:
            raise HTTPException(
                status_code=403,
                detail="You don't have permission to access this resource."
            )
        return user
    return role_checker
